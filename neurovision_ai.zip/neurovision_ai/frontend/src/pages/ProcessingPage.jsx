import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle2, Circle, Loader2 } from 'lucide-react';

const ProcessingPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { file, patientId } = location.state || {};

  const [currentStage, setCurrentStage] = useState(0);
  const [error, setError] = useState('');

  const stages = [
    "Validating image format and size",
    "Running Image Quality Assessment",
    "Preprocessing image for model",
    "Loading EfficientNet model",
    "Running inference",
    "Generating Grad-CAM visualization",
    "Preparing dashboard"
  ];

  useEffect(() => {
    if (!file || !patientId) {
      navigate('/upload');
      return;
    }

    const processImage = async () => {
      try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('patient_id', patientId);

        // Simulate stages for UI purposes before fetching
        const stageInterval = setInterval(() => {
          setCurrentStage(prev => {
            if (prev < 4) return prev + 1;
            return prev;
          });
        }, 800);

        const response = await fetch('http://localhost:8000/api/predict', {
          method: 'POST',
          body: formData,
        });

        clearInterval(stageInterval);
        
        if (!response.ok) {
          throw new Error('Analysis failed on the server.');
        }

        const data = await response.json();
        
        setCurrentStage(5);
        setTimeout(() => setCurrentStage(6), 500);
        setTimeout(() => setCurrentStage(7), 1000);
        
        setTimeout(() => {
          navigate('/results', { state: { results: data } });
        }, 1500);

      } catch (err) {
        setError(err.message || 'An error occurred during processing.');
      }
    };

    processImage();
  }, [file, patientId, navigate]);

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-md w-full glass-dark rounded-3xl p-8 relative overflow-hidden">
        {/* Glow effect */}
        <div className="absolute -top-20 -right-20 w-40 h-40 bg-brand-purple rounded-full blur-[80px] opacity-30"></div>
        
        <div className="text-center mb-10">
          <h2 className="text-2xl font-bold text-white mb-2">Analyzing Scan</h2>
          <p className="text-slate-400 text-sm">Patient ID: <span className="text-white font-medium">{patientId}</span></p>
        </div>

        {error ? (
          <div className="text-center text-red-400 p-4 bg-red-900/20 rounded-xl border border-red-900/50">
            <p className="font-semibold mb-4">{error}</p>
            <button onClick={() => navigate('/upload')} className="px-6 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700">Go Back</button>
          </div>
        ) : (
          <div className="space-y-4">
            {stages.map((stage, idx) => {
              const isCompleted = idx < currentStage;
              const isCurrent = idx === currentStage;
              
              return (
                <div key={idx} className={`flex items-center space-x-4 ${isCompleted ? 'text-brand-lightBlue' : isCurrent ? 'text-white' : 'text-slate-600'}`}>
                  <div className="flex-shrink-0">
                    {isCompleted ? (
                      <CheckCircle2 className="w-6 h-6" />
                    ) : isCurrent ? (
                      <Loader2 className="w-6 h-6 animate-spin" />
                    ) : (
                      <Circle className="w-6 h-6 opacity-50" />
                    )}
                  </div>
                  <span className={`text-sm font-medium ${isCurrent ? 'animate-pulse' : ''}`}>{stage}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProcessingPage;
