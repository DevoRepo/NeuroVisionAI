import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Download, AlertTriangle, ShieldCheck, ChevronLeft, Info, ZoomIn } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import logo from '../assets/logo.png';

const ResultsDashboard = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { results } = location.state || {};
  const [zoomedImage, setZoomedImage] = useState(null);

  if (!results) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center">
        <p className="text-xl text-slate-600 mb-4">No results found.</p>
        <button onClick={() => navigate('/upload')} className="px-6 py-2 bg-brand-blue text-white rounded-lg">Go to Upload</button>
      </div>
    );
  }

  const { prediction, quality, images, patient_id, report_id } = results;

  const handleDownloadPDF = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/generate-pdf', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(results),
      });
      
      if (!response.ok) throw new Error('Failed to generate PDF');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `NeuroVision_Report_${patient_id}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) {
      alert('Error downloading PDF: ' + err.message);
    }
  };

  const probData = Object.keys(prediction.probabilities).map(key => ({
    name: key.charAt(0).toUpperCase() + key.slice(1),
    value: (prediction.probabilities[key] * 100),
    color: key === prediction.class ? '#6D28D9' : '#94A3B8'
  }));

  const getQualityColor = (grade) => {
    switch (grade) {
      case 'Excellent': return 'text-green-600 bg-green-50 border-green-200';
      case 'Good': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case 'Fair': return 'text-amber-600 bg-amber-50 border-amber-200';
      default: return 'text-red-600 bg-red-50 border-red-200';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans pb-12">
      {/* Zoom Modal */}
      {zoomedImage && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setZoomedImage(null)}>
          <img src={`data:image/png;base64,${zoomedImage}`} alt="Zoomed" className="max-w-full max-h-full object-contain rounded-lg" />
          <button className="absolute top-6 right-6 text-white bg-white/20 p-2 rounded-full hover:bg-white/40">✕</button>
        </div>
      )}

      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button onClick={() => navigate('/')} className="p-2 -ml-2 rounded-lg hover:bg-slate-100 text-slate-500 transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <img src={logo} alt="Logo" className="w-8 h-8 rounded-full" />
            <h1 className="text-xl font-bold text-slate-800">NeuroVision AI Results</h1>
          </div>
          <button onClick={handleDownloadPDF} className="flex items-center space-x-2 px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors text-sm font-medium shadow-md">
            <Download className="w-4 h-4" />
            <span>Export PDF</span>
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 space-y-8">
        
        {/* Top Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Patient ID</span>
            <span className="text-xl font-bold text-slate-800">{patient_id}</span>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Report ID</span>
            <span className="text-xl font-bold text-slate-800">{report_id}</span>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Model Info</span>
            <span className="text-sm font-bold text-slate-800 leading-tight">EfficientNet-B0<br/><span className="text-xs text-slate-500 font-normal">Fine-tuned (PyTorch)</span></span>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Processing Time</span>
            <span className="text-xl font-bold text-slate-800">{prediction.time_seconds.toFixed(2)}s</span>
            <span className="text-xs text-slate-400 mt-1">on {prediction.device.toUpperCase()}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Prediction Column */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Visualizations Card */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-slate-800">Visual Explanations (Grad-CAM)</h2>
                  <p className="text-sm text-slate-500">Red regions indicate areas that contributed most strongly to the prediction.</p>
                </div>
              </div>
              
              <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50/50">
                <div className="group relative rounded-xl overflow-hidden bg-black aspect-square cursor-zoom-in border border-slate-200 shadow-inner" onClick={() => setZoomedImage(images.original)}>
                  <img src={`data:image/png;base64,${images.original}`} alt="Original" className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-xs font-semibold text-white">Original MRI</div>
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-opacity w-8 h-8 drop-shadow-md" />
                  </div>
                </div>
                
                <div className="group relative rounded-xl overflow-hidden bg-black aspect-square cursor-zoom-in border border-slate-200 shadow-inner" onClick={() => setZoomedImage(images.heatmap)}>
                  <img src={`data:image/png;base64,${images.heatmap}`} alt="Heatmap" className="w-full h-full object-cover" />
                  <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-xs font-semibold text-white">Heatmap</div>
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-opacity w-8 h-8 drop-shadow-md" />
                  </div>
                </div>
                
                <div className="group relative rounded-xl overflow-hidden bg-black aspect-square cursor-zoom-in border border-slate-200 shadow-inner" onClick={() => setZoomedImage(images.overlay)}>
                  <img src={`data:image/png;base64,${images.overlay}`} alt="Overlay" className="w-full h-full object-cover" />
                  <div className="absolute top-2 left-2 bg-brand-purple/90 backdrop-blur-md px-2 py-1 rounded text-xs font-semibold text-white shadow-sm">Overlay</div>
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-opacity w-8 h-8 drop-shadow-md" />
                  </div>
                </div>
              </div>
            </div>

            {/* Quality Metrics */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
              <h2 className="text-lg font-bold text-slate-800 mb-6">Image Quality Assessment</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="flex flex-col items-center justify-center">
                  <div className={`w-40 h-40 rounded-full border-8 flex flex-col items-center justify-center mb-4 ${getQualityColor(quality.quality_grade)}`}>
                    <span className="text-4xl font-extrabold">{quality.overall_score.toFixed(0)}</span>
                    <span className="text-sm font-semibold uppercase">Score</span>
                  </div>
                  <div className={`px-4 py-1 rounded-full text-sm font-bold border ${getQualityColor(quality.quality_grade)}`}>
                    {quality.quality_grade.toUpperCase()}
                  </div>
                </div>
                
                <div className="space-y-4">
                  {[
                    { name: 'Sharpness', data: quality.sharpness },
                    { name: 'Brightness', data: quality.brightness },
                    { name: 'Contrast', data: quality.contrast },
                    { name: 'Noise', data: quality.noise }
                  ].map(metric => (
                    <div key={metric.name}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-semibold text-slate-700">{metric.name}</span>
                        <span className="text-slate-500">{metric.data.label} ({metric.data.normalized.toFixed(2)})</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2">
                        <div className={`h-2 rounded-full ${metric.name === 'Noise' ? 'bg-amber-400' : 'bg-brand-lightBlue'}`} style={{ width: `${metric.data.normalized * 100}%` }}></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            
            {/* Primary Prediction */}
            <div className="bg-gradient-to-br from-brand-blue to-brand-purple rounded-3xl shadow-lg p-1 relative overflow-hidden">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
              <div className="bg-white/10 backdrop-blur-md rounded-[22px] p-6 text-white relative z-10">
                <div className="flex items-center space-x-2 mb-4 text-blue-200">
                  <ShieldCheck className="w-5 h-5" />
                  <span className="text-sm font-medium uppercase tracking-wider">AI Diagnosis</span>
                </div>
                <div className="mb-2">
                  <span className="text-4xl font-extrabold capitalize drop-shadow-sm">{prediction.class}</span>
                </div>
                <div className="flex items-baseline space-x-2 mb-6">
                  <span className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-300 to-white">
                    {(prediction.confidence * 100).toFixed(1)}%
                  </span>
                  <span className="text-blue-200 font-medium">Confidence</span>
                </div>
                
                <div className="bg-black/20 rounded-xl p-4 mt-2">
                  <h4 className="text-xs text-blue-200 uppercase font-semibold mb-3">Probability Distribution</h4>
                  <div className="h-40 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={probData} layout="vertical" margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fill: '#E2E8F0', fontSize: 12 }} />
                        <Tooltip cursor={{ fill: 'rgba(255,255,255,0.1)' }} contentStyle={{ backgroundColor: '#1E293B', border: 'none', borderRadius: '8px', color: '#fff' }} />
                        <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={12}>
                          {probData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color === '#6D28D9' ? '#60A5FA' : '#94A3B8'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>

            {/* Placeholders */}
            <div className="bg-slate-100 rounded-3xl border border-slate-200 p-6 flex flex-col items-center justify-center text-center opacity-70">
              <div className="w-12 h-12 bg-slate-200 rounded-full flex items-center justify-center text-slate-400 mb-3">
                <Info className="w-6 h-6" />
              </div>
              <h3 className="text-slate-700 font-bold mb-1">Radiomics Module</h3>
              <p className="text-xs text-slate-500">Advanced texture analysis coming soon.</p>
            </div>

            {/* Disclaimer */}
            <div className="bg-amber-50 rounded-2xl border border-amber-200 p-4 flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-amber-800 font-medium leading-relaxed">
                <span className="font-bold">Medical Disclaimer:</span> This report is generated by NeuroVision AI for research and decision-support purposes only. It is NOT a definitive medical diagnosis. All results must be reviewed by a qualified radiologist.
              </p>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
};

export default ResultsDashboard;
