import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import logo from '../assets/logo.png';

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-brand-blue via-brand-purple to-gray-900 flex flex-col items-center justify-center overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-[20%] -left-[10%] w-[50vw] h-[50vw] rounded-full bg-brand-lightBlue filter blur-[120px] opacity-30"
        />
        <motion.div
          animate={{ scale: [1, 1.5, 1], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
          className="absolute top-[40%] -right-[10%] w-[60vw] h-[60vw] rounded-full bg-brand-lightPurple filter blur-[150px] opacity-20"
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="z-10 flex flex-col items-center text-center px-4"
      >
        <div className="bg-white/10 p-6 rounded-full backdrop-blur-md mb-8 border border-white/20 shadow-2xl">
          <img src={logo} alt="NeuroVision AI Logo" className="w-40 h-40 object-contain rounded-full shadow-lg" />
        </div>
        
        <h1 className="text-6xl md:text-8xl font-extrabold text-white tracking-tight mb-4 drop-shadow-lg">
          NeuroVision <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">AI</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mb-12 font-light leading-relaxed">
          Explainable AI Decision Support Platform for Brain MRI Analysis
        </p>
        
        <motion.button
          whileHover={{ scale: 1.05, boxShadow: "0px 0px 20px rgba(59, 130, 246, 0.6)" }}
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate('/upload')}
          className="px-12 py-5 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xl font-semibold rounded-full shadow-xl transition-all border border-blue-400/30 backdrop-blur-sm"
        >
          WELCOME
        </motion.button>
      </motion.div>
    </div>
  );
};

export default LandingPage;
