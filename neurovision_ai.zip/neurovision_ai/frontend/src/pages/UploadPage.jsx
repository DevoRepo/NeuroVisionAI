import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { UploadCloud, FileImage, X, ArrowRight, AlertCircle } from 'lucide-react';
import logo from '../assets/logo.png';

const UploadPage = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  
  const [patientId, setPatientId] = useState('');
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [error, setError] = useState('');

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    validateAndSetFile(selectedFile);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    validateAndSetFile(droppedFile);
  };

  const validateAndSetFile = (file) => {
    setError('');
    if (!file) return;
    
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!validTypes.includes(file.type)) {
      setError('Please upload a valid image file (JPG, JPEG, or PNG).');
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) { // 10MB
      setError('Image size exceeds the 10MB limit.');
      return;
    }
    
    setFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const removeFile = () => {
    setFile(null);
    setPreviewUrl('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!patientId.trim()) {
      setError('Patient ID is required.');
      return;
    }
    if (!file) {
      setError('Please upload an MRI image.');
      return;
    }
    
    // Store data to pass to processing page
    navigate('/processing', { state: { file, patientId } });
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8 flex flex-col relative overflow-hidden">
      {/* Decorative blobs */}
      <div className="absolute top-0 left-0 w-full h-96 bg-brand-blue rounded-b-[50%] blur-[100px] opacity-10 pointer-events-none"></div>
      
      <div className="max-w-4xl mx-auto w-full z-10">
        <div className="flex items-center justify-between mb-12">
          <div className="flex items-center space-x-4 cursor-pointer" onClick={() => navigate('/')}>
            <img src={logo} alt="Logo" className="w-12 h-12 rounded-full" />
            <h2 className="text-2xl font-bold text-slate-800">NeuroVision AI</h2>
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden"
        >
          <div className="flex flex-col md:flex-row">
            {/* Left side: Instructions */}
            <div className="bg-gradient-to-br from-brand-blue to-brand-purple p-10 md:w-2/5 text-white flex flex-col justify-center">
              <h3 className="text-3xl font-bold mb-4">Patient Scan Upload</h3>
              <p className="text-blue-100 mb-8 leading-relaxed">
                Upload a brain MRI scan for automated AI analysis. Our system will generate explainable predictions and assess image quality.
              </p>
              
              <div className="space-y-4 text-sm text-blue-50">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">1</div>
                  <span>Enter unique Patient ID</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">2</div>
                  <span>Upload T1c or T2 MRI slice (JPG/PNG)</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">3</div>
                  <span>Submit for processing</span>
                </div>
              </div>
            </div>

            {/* Right side: Form */}
            <div className="p-10 md:w-3/5">
              <AnimatePresence>
                {error && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-start space-x-3 text-red-600"
                  >
                    <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <p className="text-sm font-medium">{error}</p>
                  </motion.div>
                )}
              </AnimatePresence>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Patient ID <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    value={patientId}
                    onChange={(e) => setPatientId(e.target.value)}
                    className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-purple focus:border-transparent transition-all outline-none text-slate-700 font-medium"
                    placeholder="e.g. PID-983472"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">MRI Scan Image <span className="text-red-500">*</span></label>
                  
                  {!file ? (
                    <div 
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={handleDrop}
                      className="border-2 border-dashed border-slate-300 rounded-2xl bg-slate-50 p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-slate-100 hover:border-brand-purple transition-all group"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileChange} 
                        accept="image/jpeg, image/jpg, image/png" 
                        className="hidden" 
                      />
                      <div className="w-16 h-16 bg-blue-100 text-brand-blue rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                        <UploadCloud className="w-8 h-8" />
                      </div>
                      <p className="text-slate-700 font-medium mb-1">Click to upload or drag and drop</p>
                      <p className="text-slate-500 text-sm">JPG, JPEG or PNG (max. 10MB)</p>
                    </div>
                  ) : (
                    <div className="relative border border-slate-200 rounded-2xl p-4 bg-slate-50 flex items-center space-x-4">
                      <div className="w-20 h-20 bg-black rounded-lg overflow-hidden flex-shrink-0">
                        <img src={previewUrl} alt="Preview" className="w-full h-full object-cover opacity-80" />
                      </div>
                      <div className="flex-grow min-w-0">
                        <p className="text-sm font-semibold text-slate-800 truncate">{file.name}</p>
                        <p className="text-xs text-slate-500">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                      </div>
                      <button 
                        type="button" 
                        onClick={removeFile}
                        className="w-10 h-10 rounded-full hover:bg-red-100 text-slate-400 hover:text-red-500 flex items-center justify-center transition-colors focus:outline-none"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="pt-4 flex items-center space-x-4">
                  <button
                    type="button"
                    onClick={() => {
                      setPatientId('');
                      removeFile();
                      setError('');
                    }}
                    className="px-6 py-3 border border-slate-300 text-slate-600 font-medium rounded-xl hover:bg-slate-50 transition-colors focus:outline-none"
                  >
                    Reset
                  </button>
                  <button
                    type="submit"
                    className="flex-grow flex items-center justify-center space-x-2 px-6 py-3 bg-brand-blue text-white font-semibold rounded-xl hover:bg-blue-800 shadow-md shadow-blue-900/20 transition-all focus:outline-none"
                  >
                    <span>Submit for Analysis</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default UploadPage;
