import io
import base64
import time
import torch
import torch.nn.functional as F
from PIL import Image
import cv2
import numpy as np

from app.ml.model_loader import get_model, get_device
from app.ml.preprocessing import preprocess_image
from app.ml.gradcam import generate_gradcam
from app.ml.image_quality import assess_image_quality
from app.core.config import settings

def encode_image_base64(image: Image.Image) -> str:
    buffered = io.BytesIO()
    image.save(buffered, format="PNG")
    return base64.b64encode(buffered.getvalue()).decode('utf-8')

def run_prediction_pipeline(file_bytes: bytes):
    start_time = time.time()
    
    # Load image
    image = Image.open(io.BytesIO(file_bytes)).convert("RGB")
    original_b64 = encode_image_base64(image)
    
    # Assess image quality
    gray_image = np.array(image.convert("L"))
    iqa_results = assess_image_quality(gray_image)
    
    # Preprocess
    input_tensor = preprocess_image(image)
    
    # Predict
    model = get_model()
    device = get_device()
    input_tensor = input_tensor.to(device)
    
    with torch.no_grad():
        outputs = model(input_tensor)
        probabilities = F.softmax(outputs, dim=1).cpu().numpy()[0]
        pred_idx = int(np.argmax(probabilities))
        confidence = float(probabilities[pred_idx])
    
    predicted_class = settings.CLASSES[pred_idx]
    
    # Probability distribution
    prob_dist = {settings.CLASSES[i]: float(probabilities[i]) for i in range(len(settings.CLASSES))}
    
    # Grad-CAM
    heatmap_bgr, overlay_bgr = generate_gradcam(image, pred_idx)
    
    # Convert BGR (OpenCV) to RGB (PIL) for sending to frontend
    heatmap_rgb = cv2.cvtColor(heatmap_bgr, cv2.COLOR_BGR2RGB)
    overlay_rgb = cv2.cvtColor(overlay_bgr, cv2.COLOR_BGR2RGB)
    
    heatmap_pil = Image.fromarray(heatmap_rgb)
    overlay_pil = Image.fromarray(overlay_rgb)
    
    heatmap_b64 = encode_image_base64(heatmap_pil)
    overlay_b64 = encode_image_base64(overlay_pil)
    
    processing_time = time.time() - start_time
    
    return {
        "prediction": {
            "class": predicted_class,
            "confidence": confidence,
            "probabilities": prob_dist,
            "time_seconds": processing_time,
            "device": str(device),
            "resolution": f"{image.width}x{image.height}"
        },
        "quality": iqa_results,
        "images": {
            "original": original_b64,
            "heatmap": heatmap_b64,
            "overlay": overlay_b64
        }
    }
