import numpy as np
import cv2
import math
from typing import Dict
from dataclasses import dataclass

@dataclass
class QualityWeights:
    sharpness: float = 0.40
    contrast: float = 0.25
    brightness: float = 0.20
    noise: float = 0.15

    def validate(self):
        total = self.sharpness + self.contrast + self.brightness + self.noise
        if not math.isclose(total, 1.0, abs_tol=1e-6):
            raise ValueError(f"Quality weights must sum to 1.0 (got {total:.4f})")

def compute_sharpness(gray: np.ndarray, ref_max: float = 1500.0) -> Dict[str, float]:
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    raw_sharpness = float(np.var(laplacian))

    if ref_max <= 0 or np.isnan(raw_sharpness):
        normalized = 0.0
    else:
        normalized = float(np.clip(raw_sharpness / ref_max, 0.0, 1.0))

    if normalized >= 0.75:
        label = "Sharp"
    elif normalized >= 0.4:
        label = "Acceptable"
    else:
        label = "Blurry"

    return {"raw": raw_sharpness, "normalized": normalized, "label": label}

def compute_brightness(gray: np.ndarray) -> Dict[str, float]:
    raw_brightness = float(np.mean(gray))
    normalized = float(np.clip(raw_brightness / 255.0, 0.0, 1.0))

    if normalized < 0.25:
        label = "Too Dark"
    elif normalized > 0.80:
        label = "Too Bright"
    else:
        label = "Normal"

    return {"raw": raw_brightness, "normalized": normalized, "label": label}

def compute_contrast(gray: np.ndarray, ref_max: float = 80.0) -> Dict[str, float]:
    raw_contrast = float(np.std(gray))

    if ref_max <= 0 or np.isnan(raw_contrast):
        normalized = 0.0
    else:
        normalized = float(np.clip(raw_contrast / ref_max, 0.0, 1.0))

    if normalized >= 0.7:
        label = "High Contrast"
    elif normalized >= 0.35:
        label = "Moderate Contrast"
    else:
        label = "Low Contrast"

    return {"raw": raw_contrast, "normalized": normalized, "label": label}

def compute_noise(gray: np.ndarray, kernel_size: int = 5, ref_max: float = 25.0) -> Dict[str, float]:
    if kernel_size % 2 == 0:
        kernel_size += 1

    median_filtered = cv2.medianBlur(gray, kernel_size)
    residual = gray.astype(np.float32) - median_filtered.astype(np.float32)
    raw_noise = float(np.std(residual))

    if ref_max <= 0 or np.isnan(raw_noise):
        normalized = 0.0
    else:
        normalized = float(np.clip(raw_noise / ref_max, 0.0, 1.0))

    if normalized <= 0.25:
        label = "Low Noise (Clean)"
    elif normalized <= 0.5:
        label = "Moderate Noise"
    else:
        label = "High Noise"

    return {"raw": raw_noise, "normalized": normalized, "label": label}

def compute_overall_score(sharpness_norm: float, brightness_norm: float,
                           contrast_norm: float, noise_norm: float,
                           weights: QualityWeights = QualityWeights()) -> float:
    weights.validate()

    s = float(np.clip(np.nan_to_num(sharpness_norm), 0.0, 1.0))
    b = float(np.clip(np.nan_to_num(brightness_norm), 0.0, 1.0))
    c = float(np.clip(np.nan_to_num(contrast_norm), 0.0, 1.0))
    n = float(np.clip(np.nan_to_num(noise_norm), 0.0, 1.0))

    weighted_sum = (
        weights.sharpness * s +
        weights.contrast * c +
        weights.brightness * b +
        weights.noise * (1.0 - n)
    )
    return float(np.clip(weighted_sum * 100.0, 0.0, 100.0))

def get_quality_grade(score: float) -> str:
    if score >= 90:
        return "Excellent"
    elif score >= 75:
        return "Good"
    elif score >= 60:
        return "Fair"
    else:
        return "Poor"

def assess_image_quality(image_array: np.ndarray):
    """
    Assesses image quality given a grayscale numpy array.
    """
    sharp = compute_sharpness(image_array)
    bright = compute_brightness(image_array)
    contr = compute_contrast(image_array)
    nz = compute_noise(image_array)

    score = compute_overall_score(
        sharpness_norm=sharp["normalized"],
        brightness_norm=bright["normalized"],
        contrast_norm=contr["normalized"],
        noise_norm=nz["normalized"],
    )
    grade = get_quality_grade(score)
    
    return {
        "sharpness": sharp,
        "brightness": bright,
        "contrast": contr,
        "noise": nz,
        "overall_score": score,
        "quality_grade": grade
    }
