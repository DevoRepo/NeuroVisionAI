import numpy as np
import cv2
import torch
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from pytorch_grad_cam.utils.image import show_cam_on_image
from PIL import Image
from app.ml.model_loader import get_model, get_device
from app.ml.preprocessing import get_test_transform

def generate_gradcam(image: Image.Image, pred_idx: int):
    """
    Generates a Grad-CAM heatmap and overlay for the given image and prediction index.
    Returns: (heatmap_bgr, overlay_bgr)
    """
    model = get_model()
    device = get_device()
    
    # Preprocess image
    transform = get_test_transform()
    input_tensor = transform(image).unsqueeze(0).to(device)
    
    # target_layers: the last MBConv block in efficientnet_b0
    target_layers = [model.features[8]]
    
    cam = GradCAM(model=model, target_layers=target_layers)
    
    targets = [ClassifierOutputTarget(pred_idx)]
    
    # Generate CAM
    grayscale_cam = cam(input_tensor=input_tensor, targets=targets)[0]
    
    # Prepare original image for overlay
    # Convert PIL to numpy, RGB
    rgb = np.array(image.convert("RGB"))
    # Resize to 224x224 to match the tensor output size
    rgb = cv2.resize(rgb, (224, 224))
    
    # Normalize RGB for show_cam_on_image (0-1 float)
    rgb = rgb.astype(np.float32) / 255.0
    
    # Create overlay
    overlay = show_cam_on_image(rgb, grayscale_cam, use_rgb=True) # overlay is RGB uint8
    
    # Color map for heatmap
    heatmap = cv2.applyColorMap(np.uint8(255 * grayscale_cam), cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    
    return heatmap, overlay
