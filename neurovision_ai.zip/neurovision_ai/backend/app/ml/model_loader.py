import torch
import torch.nn as nn
from torchvision.models import efficientnet_b0, EfficientNet_B0_Weights
from app.core.config import settings

class ModelLoader:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Loading model on {self.device}")
        
        self.model = efficientnet_b0(weights=EfficientNet_B0_Weights.DEFAULT)
        self.model.classifier = nn.Sequential(
            nn.Dropout(0.2),
            nn.Linear(1280, 4)
        )
        
        try:
            self.model.load_state_dict(torch.load(settings.MODEL_PATH, map_location=self.device))
            print("✅ Model loaded successfully from:", settings.MODEL_PATH)
        except Exception as e:
            print(f"⚠️ Warning: Could not load model weights from {settings.MODEL_PATH}. Error: {e}")
            
        self.model = self.model.to(self.device)
        self.model.eval()

def get_model():
    return ModelLoader.get_instance().model

def get_device():
    return ModelLoader.get_instance().device
