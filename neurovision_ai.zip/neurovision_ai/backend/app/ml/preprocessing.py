from torchvision import transforms
from PIL import Image

def get_test_transform():
    return transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    ])

def preprocess_image(image: Image.Image):
    transform = get_test_transform()
    tensor = transform(image)
    return tensor.unsqueeze(0)  # Add batch dimension
