from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse, Response
from typing import Optional
import json

from app.ml.predict import run_prediction_pipeline
from app.services.pdf_generator import generate_pdf_report

router = APIRouter()

@router.post("/predict")
async def predict_mri(
    patient_id: str = Form(...),
    file: UploadFile = File(...)
):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File provided is not an image.")
    
    try:
        file_bytes = await file.read()
        results = run_prediction_pipeline(file_bytes)
        
        # We can pass patient_id back in response
        results["patient_id"] = patient_id
        
        # We also want to generate a unique report ID
        import uuid
        report_id = str(uuid.uuid4())[:8].upper()
        results["report_id"] = report_id
        
        return JSONResponse(content=results)
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

@router.post("/generate-pdf")
async def generate_pdf(
    payload: dict
):
    try:
        patient_id = payload.get("patient_id", "UNKNOWN")
        report_id = payload.get("report_id", "UNKNOWN")
        prediction_data = payload.get("prediction", {})
        quality_data = payload.get("quality", {})
        images_data = payload.get("images", {})
        
        pdf_bytes = generate_pdf_report(
            patient_id=patient_id,
            report_id=report_id,
            prediction_data=prediction_data,
            quality_data=quality_data,
            images_data=images_data
        )
        
        return Response(content=pdf_bytes, media_type="application/pdf", headers={
            "Content-Disposition": f"attachment; filename=NeuroVision_Report_{patient_id}.pdf"
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to generate PDF: {str(e)}")
