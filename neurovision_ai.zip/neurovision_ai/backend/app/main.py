from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import router
from app.ml.model_loader import ModelLoader

app = FastAPI(title="NeuroVision AI API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow frontend to communicate
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup_event():
    # Initialize the model on startup so the first request isn't slow
    ModelLoader.get_instance()
    print("NeuroVision AI backend started successfully.")

app.include_router(router, prefix="/api")
