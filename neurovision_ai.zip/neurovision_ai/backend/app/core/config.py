import os

class Settings:
    PROJECT_NAME: str = "NeuroVision AI Backend"
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    MODELS_DIR = os.path.join(BASE_DIR, "models")
    REPORTS_DIR = os.path.join(BASE_DIR, "reports")
    UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
    
    MODEL_PATH = os.path.join(MODELS_DIR, "best_model_finetuned.pth")

    # Classes in alphabetical order as defined by standard Kaggle dataset used during training
    CLASSES = ["glioma", "meningioma", "notumor", "pituitary"]

settings = Settings()
